import "./App.css";
import Start from "./components/Start.js";

function App() {
  return (
    <>
      <Start/>
    </>
  );
}

export default App;
